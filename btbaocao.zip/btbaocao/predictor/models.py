from django.db import models


class Student(models.Model):

    age = models.IntegerField()
    gender = models.IntegerField()
    ethnicity = models.IntegerField()
    parental_education = models.IntegerField()

    study_time_weekly = models.FloatField()
    absences = models.IntegerField()

    tutoring = models.IntegerField()
    parental_support = models.IntegerField()

    extracurricular = models.IntegerField()
    sports = models.IntegerField()
    music = models.IntegerField()
    volunteering = models.IntegerField()

    gpa = models.FloatField()

    def __str__(self):
        return f"Student GPA={self.gpa}"


class TrainingResult(models.Model):

    rmse = models.FloatField()

    r2_score = models.FloatField()

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"R2={self.r2_score:.4f}"