import os
import json
import pickle
import numpy as np
import pandas as pd
from django.shortcuts import render
from .models import TrainingResult
from django.http import HttpResponseRedirect

FEATURES = [
    'age',
    'gender',
    'ethnicity',
    'parental_education',
    'study_time_weekly',
    'absences',
    'tutoring',
    'parental_support',
    'extracurricular',
    'sports',
    'music',
    'volunteering',
]

# ── Load model & features một lần khi Django khởi động ──────────────────────
BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
ML_DIR    = os.path.join(BASE_DIR, "ml")

# Thử load sklearn model (.pkl). Nếu không có thì dùng numpy model (.npz)
_pkl_path = os.path.join(ML_DIR, "model.pkl")
_npz_path = os.path.join(ML_DIR, "model.npz")

USE_SKLEARN = False
model  = None
theta  = mu = sigma = None

if os.path.exists(_pkl_path):
    try:
        model = pickle.load(open(_pkl_path, "rb"))
        features = pickle.load(open(os.path.join(ML_DIR, "features.pkl"), "rb"))
        USE_SKLEARN = True
    except Exception:
        pass

if not USE_SKLEARN and os.path.exists(_npz_path):
    data     = np.load(_npz_path)
    theta    = data["theta"]
    mu       = data["mu"]
    sigma    = data["sigma"]
    features = [
        'Age', 'Gender', 'Ethnicity', 'ParentalEducation',
        'StudyTimeWeekly', 'Absences', 'Tutoring',
        'ParentalSupport', 'Extracurricular', 'Sports', 'Music', 'Volunteering',
    ]

# ── Load dataset cho biểu đồ ────────────────────────────────────────────────
_csv_path = os.path.join(BASE_DIR, "data", "Students_performance_data.csv")
df = pd.read_csv(_csv_path)


def _get_chart_data(use_median=False):
    """Trả về (labels, values) cho biểu đồ GPA theo giờ học."""
    df_copy = df.copy()
    df_copy["StudyTimeGroup"] = df_copy["StudyTimeWeekly"].astype(int)
    fn = "median" if use_median else "mean"
    avg_gpa = df_copy.groupby("StudyTimeGroup")["GPA"].agg(fn)
    return list(avg_gpa.index), [round(v, 3) for v in avg_gpa.values]


def _label(pred):
    if pred >= 3.5:
        return "Xuất sắc 🔥"
    elif pred >= 3.0:
        return "Giỏi 🎉"
    elif pred >= 2.5:
        return "Khá 👍"
    elif pred >= 2.0:
        return "Trung bình 😐"
    else:
        return "Cần cải thiện ⚠️"


def home(request):
    study, gpa = _get_chart_data()
    return render(request, "predictor/index.html", {
        "features":   FEATURES,
        "study":      json.dumps(study),
        "gpa":        json.dumps(gpa),
        "prediction": "",
        "pred_value": "",
        "error":      "",
    })


def predict(request):
    if request.method != "POST":
        return HttpResponseRedirect("/")

    try:
        input_data = [float(request.POST.get(f, 0)) for f in FEATURES]

        if USE_SKLEARN:
            pred = float(model.predict([input_data])[0])
        else:
            x = np.array(input_data, dtype=float)
            x_scaled = (x - mu) / np.where(sigma == 0, 1, sigma)
            x_bias   = np.concatenate([[1.0], x_scaled])
            pred     = float(x_bias @ theta)

        pred = max(0.0, min(4.0, pred))   # clamp về khoảng [0, 4]
        msg  = _label(pred)
        prediction_msg = f"GPA dự đoán: {pred:.2f} — {msg}"
        error = ""
    except Exception as e:
        prediction_msg = ""
        error = f"Lỗi khi dự đoán: {e}"

    study, gpa = _get_chart_data(use_median=True)
    return render(request, "predictor/index.html", {
        "features":   FEATURES,
        "study":      json.dumps(study),
        "gpa":        json.dumps(gpa),
        "prediction": prediction_msg,
        "pred_value": "",
        "error":      error,
        # Giữ lại giá trị người dùng vừa nhập
        "posted":     {f: request.POST.get(f, "") for f in FEATURES},
    })

def training_result(request):

    result = TrainingResult.objects.last()

    return render(
        request,
        'predictor/training_result.html',
        {
            'result': result
        }
    )