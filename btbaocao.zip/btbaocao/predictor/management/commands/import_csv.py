import pandas as pd

from django.core.management.base import BaseCommand
from predictor.models import Student


class Command(BaseCommand):

    help = 'Import student CSV into database'

    def add_arguments(self, parser):

        parser.add_argument(
            'csv_file',
            type=str
        )

    def handle(self, *args, **kwargs):

        csv_file = kwargs['csv_file']

        df = pd.read_csv(csv_file)

        Student.objects.all().delete()

        for _, row in df.iterrows():

            Student.objects.create(

                age=row['Age'],
                gender=row['Gender'],
                ethnicity=row['Ethnicity'],
                parental_education=row['ParentalEducation'],

                study_time_weekly=row['StudyTimeWeekly'],
                absences=row['Absences'],

                tutoring=row['Tutoring'],
                parental_support=row['ParentalSupport'],

                extracurricular=row['Extracurricular'],
                sports=row['Sports'],
                music=row['Music'],
                volunteering=row['Volunteering'],

                gpa=row['GPA']
            )

        self.stdout.write(
            self.style.SUCCESS(
                f'Imported {len(df)} students successfully.'
            )
        )