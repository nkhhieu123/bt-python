import pandas as pd
import matplotlib.pyplot as plt

# ===== LOAD DATA =====
df = pd.read_csv("Students_performance_data.csv")

# ===== AUTO CLEAN =====
df = df.dropna()

# ===== AUTO ENCODE =====
for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].astype('category').cat.codes

# ===== THÔNG TIN DATA =====
print("===== INFO =====")
print(df.info())

print("\n===== DESCRIBE =====")
print(df.describe())

# ===== PHÂN TÍCH 1: Study Time vs GPA =====
plt.figure()
plt.scatter(df['StudyTimeWeekly'], df['GPA'])
plt.xlabel("Study Time Weekly")
plt.ylabel("GPA")
plt.title("Study Time vs GPA")
plt.show()

# ===== PHÂN TÍCH 2: Absences vs GPA =====
plt.figure()
plt.scatter(df['Absences'], df['GPA'])
plt.xlabel("Absences")
plt.ylabel("GPA")
plt.title("Absences vs GPA")
plt.show()

# ===== PHÂN TÍCH 3: GPA trung bình theo Study Time =====
avg_gpa = df.groupby("StudyTimeWeekly")["GPA"].mean()

plt.figure()
plt.plot(avg_gpa.index, avg_gpa.values)
plt.xlabel("Study Time Weekly")
plt.ylabel("Average GPA")
plt.title("Average GPA by Study Time")
plt.show()

# ===== PHÂN TÍCH 4: GPA theo hỗ trợ gia đình =====
support_gpa = df.groupby("ParentalSupport")["GPA"].mean()

plt.figure()
plt.bar(support_gpa.index, support_gpa.values)
plt.xlabel("Parental Support")
plt.ylabel("Average GPA")
plt.title("GPA vs Parental Support")
plt.show()

# ===== PHÂN TÍCH 5: Histogram GPA =====
plt.figure()
plt.hist(df['GPA'], bins=20)
plt.xlabel("GPA")
plt.ylabel("Frequency")
plt.title("Distribution of GPA")
plt.show()

# ===== INSIGHT AUTO =====
print("\n===== INSIGHT =====")

if df['StudyTimeWeekly'].corr(df['GPA']) > 0:
    print("✔ Học nhiều → GPA cao")

if df['Absences'].corr(df['GPA']) < 0:
    print("✔ Nghỉ nhiều → GPA thấp")

print("✔ Dataset đã được xử lý tự động")