# 🎓 GPA Predictor - Django App

## Cài đặt & chạy

```bash
pip install -r requirements.txt
cd btbaocao
python manage.py migrate
python manage.py runserver
```

Mở trình duyệt: http://127.0.0.1:8000

## Train lại model (tùy chọn)

Model hiện tại đã được train sẵn (sklearn RandomForest, lưu ở `predictor/ml/model.pkl`).

Nếu muốn train lại bằng Linear Regression thuần numpy:
```bash
python manage.py train_model --method normal
# hoặc
python manage.py train_model --method gradient --alpha 0.01 --epochs 2000
```

## Cấu trúc

```
btbaocao/
├── manage.py
├── requirements.txt
├── gpa_project/
│   ├── settings.py   ← đã sửa (trước đó rỗng)
│   ├── urls.py
│   └── wsgi.py
└── predictor/
    ├── views.py      ← đã sửa (load đúng model, xử lý lỗi)
    ├── urls.py
    ├── models.py
    ├── apps.py
    ├── templates/
    │   └── predictor/
    │       └── index.html  ← đã sửa (path đúng, UI đẹp hơn)
    ├── data/
    │   └── Students_performance_data.csv
    └── ml/
        ├── model.pkl
        └── features.pkl
```
