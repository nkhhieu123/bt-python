# =========================
# IMPORTS
# =========================

import os
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from django.core.management.base import BaseCommand, CommandError
from predictor.models import Student, TrainingResult

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score

from sklearn.ensemble import RandomForestRegressor

# =========================
# CONFIG
# =========================

MODEL_DIR = os.path.join(os.path.dirname(__file__), '..', '..', 'ml')
MODEL_PATH = os.path.join(MODEL_DIR, 'model.pkl')

FEATURES = [
    'age',
    'gender',
    'ethnicity',
    'parental_education',
    'study_time_weekly',
    'absences',
    'tutoring',
    'parental_support',
    'extracurricular',
    'sports',
    'music',
    'volunteering',
]

# =========================
# METRICS
# =========================

def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))


# =========================
# DJANGO COMMAND
# =========================

class Command(BaseCommand):

    help = 'Train Random Forest model to predict GPA'

    def handle(self, *args, **kwargs):

        # =========================
        # LOAD DATA
        # =========================

        qs = Student.objects.all()

        if not qs.exists():
            raise CommandError(
                'No students found. Run: python manage.py import_csv <file>'
            )

        rows = list(qs.values(*FEATURES, 'gpa'))
        df = pd.DataFrame(rows)

        X_raw = np.array(
            [[r[f] for f in FEATURES] for r in rows],
            dtype=float
        )

        y = np.array(
            [r['gpa'] for r in rows],
            dtype=float
        )

        self.stdout.write(
            f'Loaded {len(y)} students with {X_raw.shape[1]} features\n'
        )

        # =========================
        # VISUALIZATION
        # =========================

        categorical_columns = [
            'ethnicity',
            'age',
            'parental_education',
            'tutoring',
            'parental_support',
            'extracurricular',
            'sports',
            'music',
            'volunteering',
            'gender'
        ]

        # Custom labels
        custom_labels = {
            'ethnicity': ['Caucasian', 'African American', 'Asian', 'Other'],
            'age': [15, 16, 17, 18],
            'parental_education': [
                'None',
                'High School',
                'Some College',
                "Bachelor's",
                'Higher'
            ],
            'tutoring': ['No', 'Yes'],
            'parental_support': [
                'No',
                'Low',
                'Moderate',
                'High',
                'Very High'
            ],
            'extracurricular': ['No', 'Yes'],
            'sports': ['No', 'Yes'],
            'music': ['No', 'Yes'],
            'volunteering': ['No', 'Yes'],
            'gender': ['Male', 'Female']
        }

        # Plot countplots
        for column in categorical_columns:

            plt.figure(figsize=(8, 5))

            sns.countplot(data=df, x=column)

            plt.title(f'Countplot of {column}')

            labels = custom_labels[column]

            ticks = range(len(labels))

            plt.xticks(
                ticks=ticks,
                labels=labels
            )

            plt.tight_layout()

            plt.show()

        # =========================
        # CORRELATION HEATMAP
        # =========================

        plt.figure(figsize=(12, 10))

        # Chỉ lấy cột số
        corr_matrix = df.corr(numeric_only=True)

        # Upper triangle mask
        mask = np.triu(
            np.ones_like(corr_matrix, dtype=bool)
        )

        # Color palette
        cmap = sns.diverging_palette(
            230,
            20,
            as_cmap=True
        )

        # Heatmap
        sns.heatmap(
            corr_matrix,
            cmap=cmap,
            mask=mask,
            annot=True,
            fmt=".2f",
            linewidths=0.5,
            cbar_kws={"shrink": .5},
            vmin=-1,
            vmax=1
        )

        plt.title(
            'Correlation Matrix Heatmap',
            fontsize=16
        )

        plt.tight_layout()

        plt.show()

        # =========================
        # BOXPLOT VISUALIZATION
        # =========================

        numerical_columns = [
            'study_time_weekly',
            'absences',
            'gpa'
        ]

        fig, ax = plt.subplots(
            1,
            len(numerical_columns),
            figsize=(18, 5)
        )

        for idx, col in enumerate(numerical_columns):

            sns.boxplot(
                ax=ax[idx],
                x=df[col]
            )

            ax[idx].set_title(col)

        plt.tight_layout()

        plt.show()

        # =========================
        # FEATURE SCALING
        # =========================

        scaler = StandardScaler()

        X_scaled = scaler.fit_transform(X_raw)

        # =========================
        # TRAIN TEST SPLIT
        # =========================

        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled,
            y,
            test_size=0.2,
            random_state=42
        )

        # =========================
        # MODEL
        # =========================

        model = RandomForestRegressor(
            n_estimators=300,
            max_depth=10,
            random_state=42
        )

        self.stdout.write('Training Random Forest model...\n')

        model.fit(X_train, y_train)

        # =========================
        # PREDICTION
        # =========================

        y_pred = model.predict(X_test)

        # =========================
        # EVALUATION
        # =========================

        rmse_score = rmse(y_test, y_pred)

        r2 = r2_score(y_test, y_pred)

        TrainingResult.objects.create(
            rmse=rmse_score,
            r2_score=r2
        )

        self.stdout.write(f'RMSE : {rmse_score:.4f}')
        self.stdout.write(f'R²   : {r2:.4f}\n')

        # =========================
        # FEATURE IMPORTANCE
        # =========================

        self.stdout.write('Feature importance:\n')

        importance_pairs = sorted(
            zip(FEATURES, model.feature_importances_),
            key=lambda x: x[1],
            reverse=True
        )

        for name, importance in importance_pairs:
            self.stdout.write(
                f'  {name:<25} {importance:.4f}'
            )

        # =========================
        # SAVE MODEL
        # =========================

        os.makedirs(MODEL_DIR, exist_ok=True)

        joblib.dump(
            {
                'model': model,
                'scaler': scaler,
                'features': FEATURES
            },
            MODEL_PATH
        )

        self.stdout.write(
            self.style.SUCCESS(
                f'\nModel saved → {MODEL_PATH}'
            )
        )